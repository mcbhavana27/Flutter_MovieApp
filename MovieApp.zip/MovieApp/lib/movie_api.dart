import 'package:movieapp/models.dart';

final Movie testMovie = Movie(
  bannerUrl: 'images/poster.jpg',
  posterUrl: 'images/poster1.png',
  title: 'Gunjan Saxena',
  rating: 9.2,
  starRating: 4,
  categories: ['TRUE STORY', 'INSPIRING'],
  storyline: 'The life of Air Force pilot, Gunjan Saxena, the first Indian female pilot in comba',
  photoUrls: [
    'images/1.jpg',
    'images/2.jpg',
    'images/3.jpg',
  ],
  actors: [
    Actor(
      name: 'Janhvi Kappor',
      avatarUrl: 'images/janvi.jpg',
    ),
    Actor(
      name: 'Angad Bedi',
      avatarUrl: 'images/angad.jpeg',
    ),
    Actor(
      name: 'Pankaj Tripathi',
      avatarUrl: 'images/pankaj.jpeg',
    ),
    Actor(
      name: 'Manav vij',
      avatarUrl: 'images/manav.jpeg',
    ),
    Actor(
      name: 'Vineet kumar',
      avatarUrl: 'images/vineet.jpeg',
    ),
  ],
);
